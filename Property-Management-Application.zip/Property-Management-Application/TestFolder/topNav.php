<div id='topNav'>
	<a href='searchProperties.php'>Search Properties</a>
	<a href='registerTenant.php'>Register Tenant</a>
	<a href='tenantProfile.php'>Edit My Tenant Profile</a>
	<a href='login.php'>Login</a>
	<a href='updateWHouse.php?propertyId=1'>Update Whole-House</a>
</div>