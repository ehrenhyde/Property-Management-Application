<html lang="en">

<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-theme.min.css" rel="stylesheet">
	<link href="css/theme.css" rel="stylesheet">
	<title>Property Data</title>
	<!---<link rel='stylesheet' href = 'css/page.css' type = 'text/css'/>-->
</head>

<body>
<div class="page-header">
	<h1>Property View</h1>
</div>
<?php
	include('includes/accountSessions.php');
	include('includes/functions/db.php');
	include('includes/content/topNav.php');

	$id=(isset($_GET["data"])) ? (int)$_GET["data"] : 1;


	$result = db_getWHouseDetails($id);

			
    echo '<div id=content>';
		
		
		
		?><div class="col-xs-offset-2"><div class="col-sm-9">
		<div class="panel panel-primary">
				<div class="panel-heading"><h3 class="panel-title"><?php echo ''.$result['Address'].'';?></h3></div>
				<div class="panel-body">
				<table class="table"><tr><div align="center" id=Picture><img style="max-width: 640px; max-height: 400px" src="data:image/jpeg;base64,<?php echo base64_encode( $result["image"] ); ?>"/></div></tr><?php
		
		echo '<tr><td>Number of rooms:'. $result['NumberofRooms'].'</td><td>Suburb:'. $result['suburb'].'</td>';
				echo '<tr><td>Number of carparks:'. $result['NumberofCarParks'].'</td><td>State:'. $result['state'].' '.$result['postcode'].'</td>';
				echo '<tr><td>Number of bathrooms:'. $result['NumberofBathrooms'].'</td><td>Buying Price:'. $result['BuyingPrice'].'</td></tr>';
				echo "<td><a href='updateWHouse.php?propertyId=".$result['propertyId']."'>Edit</a></td></tr>";
				echo "<tr><td><div class=\"linediv\"></div></td></tr></table></div></div>";
		?>
	</div></div></div>
	





</body>
</html>

